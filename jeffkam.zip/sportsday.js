var event = [];
var house = [];
var gender = [];
var grade = [];
var name = [];
var id = [];
var rank = [];
var points = [];
var headers = [];

var gradeChampion12Button;
var gradeChampion11Button;
var gradeChampion10Button;
var gradeChampion9Button;
var gradeChampion8Button;
var gradeChampion7Button;
var gradeChampion6Button;

// spreadsheet variables
var ttsheet9;
var ttsheet10;
var public_spreadsheet_url = 'https://docs.google.com/spreadsheets/d/1XEcLtBW2WVSD0WqEWXzswq--a5q9tXVOK62KZpThB-A/pubhtml';

// grade 9 spreadsheet variables
var sheetninedata = [[]];
var sheetninemaxr;
var sheetninemaxc;

// grade 10 spreadsheet variables
var sheettendata = [[]];
var sheettenmaxr;
var sheettenmaxc;

// grade champion variables
// uniquedata[grade][individual student][name,points,gender,house,id];

var uniquenames = [[]];
var uniquepoints = [[]];
var uniquegender = [[]];
var uniquehouse = [[]];
var uniqueid = [[]];


var doonce;


function setup(){  

	createCanvas(950, 12000);

	// set text properties
	/*
	PFont font;
	font = loadFont("FFScala.ttf"); 
	textFont(font, 18); 
	*/

	gradeChampion12Button = loadImage("images/GradeChampion12Button.png");
	gradeChampion11Button = loadImage("images/GradeChampion11Button.png");
	gradeChampion10Button = loadImage("images/GradeChampion10Button.png");
	gradeChampion9Button = loadImage("images/GradeChampion9Button.png");
	gradeChampion8Button = loadImage("images/GradeChampion8Button.png");
	gradeChampion7Button = loadImage("images/GradeChampion7Button.png");
	gradeChampion6Button = loadImage("images/GradeChampion6Button.png");

	doonce = 0;

	init();
}  

function init() {
	ttsheet9 = Tabletop.init( { key: public_spreadsheet_url,
					 callback: loadGrade9,
					 wanted: ["Grade9"],
					  simpleSheet: true } )
	ttsheet10 = Tabletop.init( { key: public_spreadsheet_url,
					 callback: loadGrade10,
					 wanted: ["Grade10"],
					  simpleSheet: true } )
}

// process Sheet1 data
function loadGrade9(data, tabletop) {

	sheetninemaxr = 0;
	for (i = 0; i < data.length; i++)
	{
		x = data[i];
		var d = [];

		sheetninemaxc = 0;
		for (q in x) {
			fill(255,0,0);
			d[sheetninemaxc] = x[q];
			sheetninemaxc++;
		}
		sheetninedata[i] = d;      
		sheetninemaxr++;
	}
	
}

// process Sheet1 data
function loadGrade10(data, tabletop) {
	sheettenmaxr = 0;
	myData = data;
	for (i = 0; i < myData.length; i++)
	{
		x = myData[i];
		console.log(x);

		var d = [];

		sheettenmaxc = 0;
		for (q in x) {
			fill(255,0,0);
			d[sheettenmaxc] = x[q];

//			console.log(sheettenmaxc);
//			console.log(x[q]);
			sheettenmaxc++;
		}
		sheettendata[i] = d;      
		sheettenmaxr++;
	}
}

/*
function readFile12()
{
	String lines[] = loadStrings("SportsDay12.csv");

	max = lines.length-1;	
	
	text("There are " + lines.length + " lines",25,50);
	
	int i = 0;
	headers = splitTokens(lines[i],",");
	while (i < max) {

		String[] temp = splitTokens(lines[i+1],",");

		append(name,temp[0]);
		append(id,temp[1]);
		append(house,temp[2]);
		append(event,temp[3]);
		append(gender,temp[4]);
		append(grade,temp[5]);
		append(rank,temp[6]);
		append(points,temp[7]);
		

		i=i+1;
	}

}

function readFile11()
{

	String lines[] = loadStrings("SportsDay11.csv");

	max = lines.length-1;	
	
	text("There are " + lines.length + " lines",25,50);
	
	int i = 0;
	headers = splitTokens(lines[i],",");
	while (i < max) {

		String[] temp = splitTokens(lines[i+1],",");

		append(name,temp[0]);
		append(id,temp[1]);
		append(house,temp[2]);
		append(event,temp[3]);
		append(gender,temp[4]);
		append(grade,temp[5]);
		append(rank,temp[6]);
		append(points,temp[7]);

		i=i+1;
	}

}

function readFile10()
{

	String lines[] = loadStrings("SportsDay10.csv");

	max = lines.length-1;	
	
	text("There are " + lines.length + " lines",25,50);
	
	int i = 0;
	headers = splitTokens(lines[i],",");
	while (i < max) {

		String[] temp = splitTokens(lines[i+1],",");

		append(name,temp[0]);
		append(id,temp[1]);
		append(house,temp[2]);
		append(event,temp[3]);
		append(gender,temp[4]);
		append(grade,temp[5]);
		append(rank,temp[6]);
		append(points,temp[7]);

		i=i+1;
	}

}

function readFile9()
{

	String lines[] = loadStrings("SportsDay9.csv");

	max = lines.length-1;	
	
	text("There are " + lines.length + " lines",25,50);
	
	int i = 0;
	headers = splitTokens(lines[i],",");
	while (i < max) {

		String[] temp = splitTokens(lines[i+1],",");

		append(name,temp[0]);
		append(id,temp[1]);
		append(house,temp[2]);
		append(event,temp[3]);
		append(gender,temp[4]);
		append(grade,temp[5]);
		append(rank,temp[6]);
		append(points,temp[7]);

		i=i+1;
	}

}

function readFile8()
{

	String lines[] = loadStrings("SportsDay8.csv");

	max = lines.length-1;	
	
	text("There are " + lines.length + " lines",25,50);
	
	int i = 0;
	headers = splitTokens(lines[i],",");
	while (i < max) {

		String[] temp = splitTokens(lines[i+1],",");

		append(name,temp[0]);
		append(id,temp[1]);
		append(house,temp[2]);
		append(event,temp[3]);
		append(gender,temp[4]);
		append(grade,temp[5]);
		append(rank,temp[6]);
		append(points,temp[7]);

		i=i+1;
	}

}

function readFile7()
{

	String lines[] = loadStrings("SportsDay7.csv");

	max = lines.length-1;	
	
	text("There are " + lines.length + " lines",25,50);
	
	int i = 0;
	headers = splitTokens(lines[i],",");
	while (i < max) {

		String[] temp = splitTokens(lines[i+1],",");

		append(name,temp[0]);
		append(id,temp[1]);
		append(house,temp[2]);
		append(event,temp[3]);
		append(gender,temp[4]);
		append(grade,temp[5]);
		append(rank,temp[6]);
		append(points,temp[7]);

		i=i+1;
	}

}

function readFile6()
{

	String lines[] = loadStrings("SportsDay6.csv");

	max = lines.length-1;	
	
	text("There are " + lines.length + " lines",25,50);
	
	int i = 0;
	headers = splitTokens(lines[i],",");
	while (i < max) {

		String[] temp = splitTokens(lines[i+1],",");

		append(name,temp[0]);
		append(id,temp[1]);
		append(house,temp[2]);
		append(event,temp[3]);
		append(gender,temp[4]);
		append(grade,temp[5]);
		append(rank,temp[6]);
		append(points,temp[7]);
		i=i+1;
	}

}
*/


function showArray()
{

//	background(0,0,0);

/*
	text(headers[0],25,50);
	text(headers[1],25+150,50);
	text(headers[2],25+245,50);
	text(headers[3],25+350,50);
	text(headers[4],25+500,50);
	text(headers[5],25+600,50);
	text(headers[6],25+650,50);
*/

/*
	fill(0,0,0);
	j = 100;
	text(sheetninedata[0].length,400,10);
	for (r = 0; r < sheetninedata.length; r++)
	{
		for (c = 0; c < sheetninedata[r].length; c++)
		{
			if (c < sheetninedata[r].length)
			{
				text(sheetninedata[r][c],25+c*120,j+r*50);
			}
			else
			{
				text(sheetninedata[r][c],25+c*100,j+r*50);
			}
		}
	}
*/
	i = 0;
	j = 100;
	while (i < uniquenames[0].length)
	{
		text(uniquenames[0][i],50,j);
		text(uniquepoints[0][i],300,j);
		text(uniquegender[0][i],400,j);
		text(uniquehouse[0][i],500,j);
		text(uniqueid[0][i],600,j);
		i = i + 1;
		j = j + 50;
	}

}

function draw()
{
//	background(255,255,255);

	fill(0,0,0);
//	text(mouseX,50,50);
//	text(mouseY,100,50);

	drawButtons();
	if (sheetninedata[0][0] != null)
	{
		if (doonce == 0)
		{
			doonce = 1;
			findGradeChampion();
		}
		showArray();
	}
	
}

function drawButtons()
{
	image(gradeChampion12Button,800,100);
	image(gradeChampion11Button,800,150);
	image(gradeChampion10Button,800,200);
	image(gradeChampion9Button,800,250);
	image(gradeChampion8Button,800,300);
	image(gradeChampion7Button,800,350);
	image(gradeChampion6Button,800,400);
}


function findGradeChampion()
{
	// bubblesort ID first
	i = 0;
	while (i < sheetninedata.length)
	{
		j = 0;
		while (j < sheetninedata.length-1)
		{
			if (parseInt(sheetninedata[j][1]) < parseInt(sheetninedata[j+1][1]))
			{
				var temp = sheetninedata[j];
				sheetninedata[j] = sheetninedata[j+1];
				sheetninedata[j+1] = temp;
			}
			j++;
		}
		i++;
	}

	text("The following are the grade level champions",25,50);

	// add all unique names into point total
	
	
	i = 0;
	count = 0;
	total = 0;

	while(i < sheetninedata.length-1)
	{
		previous = sheetninedata[i][1];
		current = sheetninedata[i+1][1];

//		text(current,50,(i+2)*50);
//		text(previous,200,(i+2)*50);

		if (sheetninedata[i][7] != null && sheetninedata[i][7] != "")
		{
			total = total + parseInt(sheetninedata[i][7]);
		}
		if(parseInt(current) != parseInt(previous))
		{
			// unique arrays 0 - grade 9
			uniquenames[0][count] = sheetninedata[i][0];
			uniquepoints[0][count] = total;
			uniquegender[0][count] = sheetninedata[i][4];
			uniquehouse[0][count] = sheetninedata[i][2];
			uniqueid[0][count] = sheetninedata[i][1];

/*
			text(uniquenames[0][count],50,100+count*50);
			text(uniquepoints[0][count],300,100+count*50);
			text(uniquegender[0][count],400,100+count*50);
			text(uniquehouse[0][count],500,100+count*50);
			text(uniqueid[0][count],600,100+count*50);
			*/

			total = 0;
			count++;
		}
		i = i + 1;
	}
	
	// bubblesort
	
	
	i = 0;
	while (i < uniquepoints[0].length)
	{
		j = 0;
		while (j < uniquepoints[0].length-1)
		{
			if (uniquepoints[0][j] < uniquepoints[0][j+1])
			{
				temp = uniquepoints[0][j];
				uniquepoints[0][j] = uniquepoints[0][j+1];
				uniquepoints[0][j+1] = temp;

				temp = uniquenames[0][j];
				uniquenames[0][j] = uniquenames[0][j+1];
				uniquenames[0][j+1] = temp;

				temp = uniquegender[0][j];
				uniquegender[0][j] = uniquegender[0][j+1];
				uniquegender[0][j+1] = temp;

				temp = uniquehouse[0][j];
				uniquehouse[0][j] = uniquehouse[0][j+1];
				uniquehouse[0][j+1] = temp;

				temp = uniqueid[0][j];
				uniqueid[0][j] = uniqueid[0][j+1];
				uniqueid[0][j+1] = temp;
			}
			j=j+1;
		}
		i=i+1;
	}
	
	
	/*
	i = 0;
	j = 100;
	while (i < uniquenames[0].length)
	{
		text(uniquenames[0][i],50,j);
		text(uniquepoints[0][i],300,j);
		text(uniquegender[0][i],400,j);
		text(uniquehouse[0][i],500,j);
		text(uniqueid[0][i],600,j);
		i = i + 1;
		j = j + 50;
	}
	*/

}
/*
function bubbleSortPoints()
{
	int i = 0;
	
	while (i < max)
	{
		int j = 0;
		while (j < max)
		{
			if (numbers[j] > numbers[j+1])
			{
				String temp = numbers[j];
				numbers[j] = numbers[j+1];
				numbers[j+1] = temp;
			}
			j=j+1;
		}
		i=i+1;
	}
}

function clearArray()
{
	int i = 0;
	while(i < event.length)
	{
		event = shorten(event);
		house = shorten(house);
		gender = shorten(gender);
		name = shorten(name);
		id = shorten(id);
		rank = shorten(rank);
		points = shorten(points);
	}
}
*/
function mouseClicked()
{
/*
	if (mouseX > 800 && mouseX < 900 && mouseY > 50 && mouseY < 100)
	{
		clearArray();
		readFile12();	
		showArray();
	}
	if (mouseX > 800 && mouseX < 900 && mouseY > 100 && mouseY < 150)
	{
		clearArray();
		readFile12();
		findGradeChampion();
	}
	if (mouseX > 800 && mouseX < 900 && mouseY > 150 && mouseY < 200)
	{
		clearArray();
		readFile11();
		findGradeChampion();
	}
	*/
	if (mouseX > 800 && mouseX < 900 && mouseY > 200 && mouseY < 250)
	{
//		findGradeChampion(10);
	}
	if (mouseX > 800 && mouseX < 900 && mouseY > 250 && mouseY < 300)
	{
		showArray();
//		findGradeChampion(9);
	}
	/*
	if (mouseX > 800 && mouseX < 900 && mouseY > 300 && mouseY < 350)
	{
		clearArray();
		readFile8();
		findGradeChampion();
	}
	if (mouseX > 800 && mouseX < 900 && mouseY > 350 && mouseY < 400)
	{
		clearArray();
		readFile7();
		findGradeChampion();
	}
	if (mouseX > 800 && mouseX < 900 && mouseY > 400 && mouseY < 450)
	{
		clearArray();
		readFile6();
		findGradeChampion();
	}
	*/
}





